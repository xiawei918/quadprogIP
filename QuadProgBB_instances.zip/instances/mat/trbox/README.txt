This folder contains the random bound constraints generated for testing 

boxtrust.m

the code that solves the trust-region subproblem with bound constraints.

Here we just use the 42 smalllest objective data from boxqp/basic.

The problem should be loaded this way in matlab, take "spar020-100-1" for example,

    1 - load boxqp/basic/spar020-100-1.mat first
    2 - load boxqp/basic/randbox/spar020-100-1_tr.mat to overide the box constraints.
